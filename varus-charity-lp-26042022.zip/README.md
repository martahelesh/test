## How to start

`node front.js`