window.onload = function() {
    // let mobileMenuActive = false;

    // const scene = document.getElementById('scene');
    // // const parallaxInstance = new Parallax(scene);

    // const form = document.getElementById('mainForm');
    const errorMessage = document.getElementById('errorMessage');
    const btnPlus = document.getElementById('btnPlus');
    const btnMinus = document.getElementById('btnMinus');
    const btnSubmit = document.getElementById('btnSubmit');
    const emailInput = document.getElementById('email');
    const certificateCount = document.getElementById('certificateCount');
    let citySelect = document.getElementById('selectedCity');
    let selectedCity = "";

    const countRadios = document.getElementsByClassName('certificateValueButton');

    function debounce(func, timeout = 300){
        let timer;
        return (...args) => {
          clearTimeout(timer);
          timer = setTimeout(() => { func.apply(this, args); }, timeout);
        };
      }
    
    btnPlus.onclick = function () {
        const amountCount = document.getElementById('certificateCount');
        const summ = document.getElementById("certificateAmount");

        const radios = document.getElementsByName("certificateValue");
        const selected = Array.from(radios).filter(radio => radio.checked);

        if (+amountCount.value < 10000) {
            amountCount.value = +amountCount.value + 1;
        }

        if (+amountCount.value === 9999) {
            btnPlus.disabled = true; 
        }
        btnMinus.disabled = false;

        if (selected.length) {
            const value = selected[0].value;
            summ.textContent = `${+value * +amountCount.value},00 ₴`;
        }
    };
    
    btnMinus.onclick = function () {
        const amountCount = document.getElementById('certificateCount');
        const summ = document.getElementById("certificateAmount");

        const radios = document.getElementsByName("certificateValue");
        const selected = Array.from(radios).filter(radio => radio.checked);

        if (+amountCount.value > 1) {
            amountCount.value = +amountCount.value - 1;
        } 

        if (+amountCount.value <= 1) {
            btnMinus.disabled = true;
        }
        btnPlus.disabled = false;

        if (selected.length) {
            const value = selected[0].value;
            summ.textContent = `${+value * +amountCount.value},00 ₴`;
        }
    };

    certificateCount.oninput = function (e) {
        const targetValue = e.target.value;
        const summ = document.getElementById("certificateAmount");

        const radios = document.getElementsByName("certificateValue");
        const selected = Array.from(radios).filter(radio => radio.checked);

        if (selected.length) {
            const value = selected[0].value;
            summ.textContent = `${+value * +targetValue},00 ₴`;
        }
    }

    async function postData(url = '', data = {}) {
        // Default options are marked with *
        const response = await fetch(
            url, {
            method: 'POST', // *GET, POST, PUT, DELETE, etc.
            mode: "same-origin",
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify(data) // body data type must match "Content-Type" header
        });
        return response.json(); // parses JSON response into native JavaScript objects
    }

    btnSubmit.onclick = async function () {
        const url = 'buy_certificate';
        const mainForm = document.getElementById('mainForm');
        const formData = new FormData(mainForm);
        const formProps = {};


        formData.forEach((value, key) => formProps[key] = value);

        const data = {
            productName: "Це вам від щирого серця ❤️",
            productPrice: formProps.certificateValue,
            productCount: formProps.certificateCount,
            city: selectedCity,
            email: formProps.email
        };
        // console.log(data)

        btnSubmit.disabled = true;

        if (emailInput.value !== "" && selectedCity !== "") {
            postData(url, data).then(data => {
                const res = data.data;
                if (res.result === "ok") {
                    return window.location.href = res.payment_url
                    // emailInput.value = '';
                    // form.style.visibility = "hidden"
                } else {
                    errorMessage.hidden = false;
                }
                // console.log(data.data.result); // JSON data parsed by `data.json()` call
            });
        } else if (selectedCity === "") {
            citySelect.style["border"] = "2px solid red";
        } else if (emailInput.value === "") {
            emailInput.style["border"] = "2px solid red";
        } 
    };

    for (let cR of countRadios) {
        cR.onclick = function (e) {
            const targetValue = e.target.textContent;
            const summ = document.getElementById("certificateAmount");
            const amountCount = document.getElementById('certificateCount');
            const v = targetValue.trim();
            const image = document.getElementById('image');
            image.src = "./images/" + v + ".jpg";
            // console.log(image)

            summ.textContent = `${+targetValue * +amountCount.value},00 ₴`;
        }
    }

    mobileMenuToggler.onclick = function (e) {
        const target = document.getElementById('mobileMenuToggler');
        const mobileMenu = document.getElementById('mobileMenu');
        const image = document.querySelector('#mobileMenuToggler img');
        target.dataset.active = !(target.dataset.active === 'true');

        mobileMenu.style.display = target.dataset.active === 'true' ? 'block' : 'none';
        image.src = target.dataset.active === 'true' ? './images/burger-menu-close.svg' : './images/burger-menu.svg';
    };

    emailInput.oninput = debounce((e) => {
        const targetValue = e.target.value;
        const emailREg = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        const valid = emailREg.test(targetValue);

        if (valid) {
            btnSubmit.disabled = false;
        } else {
            btnSubmit.disabled = true;
        }
    });

    // CUSTOM SELECT START

    var x, i, j, l, ll, selElmnt, a, b, c;
    /* Look for any elements with the class "custom__select": */
    x = document.getElementsByClassName("custom__select");
    l = x.length;
    for (i = 0; i < l; i++) {
    selElmnt = x[i].getElementsByTagName("select")[0];
    ll = selElmnt.length;
    /* For each element, create a new DIV that will act as the selected item: */
    a = document.createElement("DIV");
    a.setAttribute("class", "select__selected");
    // a.setAttribute("id", "selectedCity");
    a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
    x[i].appendChild(a);
    /* For each element, create a new DIV that will contain the option list: */
    b = document.createElement("DIV");
    b.setAttribute("class", "select__items select__hide");
    for (j = 1; j < ll; j++) {
        /* For each option in the original select element,
        create a new DIV that will act as an option item: */
        c = document.createElement("DIV");
        c.innerHTML = selElmnt.options[j].innerHTML;
        c.addEventListener("click", function(e) {
            /* When an item is clicked, update the original select box,
            and the selected item: */
            var y, i, k, s, h, sl, yl;
            s = this.parentNode.parentNode.getElementsByTagName("select")[0];
            sl = s.length;
            h = this.parentNode.previousSibling;
            for (i = 0; i < sl; i++) {
            if (s.options[i].innerHTML == this.innerHTML) {
                s.selectedIndex = i;
                selectedCity = this.textContent.trim();
                h.innerHTML = this.innerHTML;
                btnSubmit.disabled = false;
                citySelect.style["border"] = "none";
                y = this.parentNode.getElementsByClassName("same__as__selected");
                yl = y.length;
                for (k = 0; k < yl; k++) {
                y[k].removeAttribute("class");
                }
                this.setAttribute("class", "same__as__selected");
                break;
            }
            }
            h.click();
        });
        b.appendChild(c);
    }
    x[i].appendChild(b);
    a.addEventListener("click", function(e) {
        /* When the select box is clicked, close any other select boxes,
        and open/close the current select box: */
        e.stopPropagation();
        closeAllSelect(this);
        this.nextSibling.classList.toggle("select__hide");
        this.classList.toggle("select__arrow__active");
    });
    }

    function closeAllSelect(elmnt) {
    /* A function that will close all select boxes in the document,
    except the current select box: */
    var x, y, i, xl, yl, arrNo = [];
    x = document.getElementsByClassName("select__items");
    y = document.getElementsByClassName("select__selected");
    xl = x.length;
    yl = y.length;
    for (i = 0; i < yl; i++) {
        if (elmnt == y[i]) {
        arrNo.push(i)
        } else {
        y[i].classList.remove("select__arrow__active");
        }
    }
    for (i = 0; i < xl; i++) {
        if (arrNo.indexOf(i)) {
        x[i].classList.add("select__hide");
        }
    }
    }

    /* If the user clicks anywhere outside the select box,
    then close all select boxes: */
    document.addEventListener("click", closeAllSelect);

    // CUSTOM SELECT END

};