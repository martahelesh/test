const express = require('express');
const app = express();
const path = require('path');
const router = express.Router();
const url = require('url');
const proxy = require('express-http-proxy');

const corezoid = require('./corezoid.js')

app.use(express.json())
app.use(express.static(__dirname));


router.get('/',function(req,res){
    res.sendFile(path.join(__dirname+'/index.html'));
    //__dirname : It will resolve to your project folder.
});

router.get('/success',function(req,res){
    res.sendFile(path.join(__dirname+'/success.html'));
    //__dirname : It will resolve to your project folder.
});

router.post('/buy_certificate',function(req, res){
    // console.log("req: ", req.body);
    const data = {
        "productName": req.body.productName,
        "productPrice": req.body.productPrice,
        "productCount": req.body.productCount,
        "city": req.body.city,
        "email": req.body.email,
        "isDeliveryEnabled": false
    };
    
    console.log(req.body);
    
    const login = '302';
    const secret = 'eo2tcTCPlziLa8uRJp23BgXBHz3SNq5tEkaOGJuLVdnxmpcf60';
    // console.log('app', sendRequest(data, login, secret));
    corezoid.sendRequest(data, login, secret).then(res.send.bind(res));
});
  
//add the router
app.use('/', router);
app.use('/buy_certificate', router);
app.listen(process.env.port || 3000);
console.log('Running at Port 3000');