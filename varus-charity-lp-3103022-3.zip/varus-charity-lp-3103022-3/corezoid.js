
const CryptoJS = require("crypto-js");
const axios = require('axios');

const getSignature = (body, secret, timestamp) => {
    const signature = CryptoJS.enc.Hex.stringify(
        CryptoJS.SHA1(timestamp + secret + body + secret),
    );
    return signature;
};
  
const sendRequest = (data, login, secret) => {
// console.log(data, login, secret);
    const body = JSON.stringify({
        ops: [
        {
            type: "create",
            obj: "task",
            conv_id: 7093,
            data: data
        },
        ],
    });
    
    const timestamp = Math.floor(Date.now() / 1000);
    const signature = getSignature(body, secret, timestamp);
    const url = `https://sync-api.mw.varus.ua/api/1/json/${login}/${timestamp}/${signature}`;
  
    return axios.post(url, body, {
        headers: {
        'Content-Type': 'application/json'
        }
    }).then((res) => {
        // console.log(res.headers)
        const result = (res.data && res.data.ops && res.data.ops[0]) || {};
        if (result.proc === 'ok' && result.data.result !== "error") {
            console.log(result)
            return result;
        }
        console.log(result)
        return {
            code: 400,
            status: result.data.result,
            error: result.data.reason
        };
    });
    
};


module.exports = {
    sendRequest: sendRequest,
};